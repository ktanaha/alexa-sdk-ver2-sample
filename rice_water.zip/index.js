'use-strict'

const Core = require('ask-sdk-core');
const Model = require('ask-sdk-model');

const skillBuilder = Core.SkillBuilders.custom();
exports.handler = skillBuilders
    .addRequestHandlers(
        LaunchRequestHandler,
        RiceIntentProgressHandler,
        HelpIntentHandler,
        ExitIntentHandler
    )
    .addErrorHandlers(ErrorHandler)
    .lambda();

/* Intent Handlers */
const LaunchRequestHandler = {
    canHandle(handlerInput) {
        return handlerInput.requestEnvelope.request.type === 'LaunchRequest';
    },
    handle(handlerInput) {
        const speechText = '炊きたいお米の量を合数で教えてください。';
        return handlerInput.responseBuilder
            .speak(speechText)
            .reprompt(speechText)
            .withSimpleCard('お米のお水', speechText)
            .getResponse();
    }
};

const RiceIntentProgressHandler = {
    canHandle(handlerInput) {
        const request = handlerInput.requestEnvelope.request;
        console.log(JSON.stringify(request));
        return request.type === 'IntentRequest' &&
               request.intent.name === 'RiceIntent' &&
               request.dialogState !== 'COMPLETED';
    },
    handle(handlerInput) {
        const attributes = handlerInput.attributesManager.getSessionAttributes();
        const response = handlerInput.responseBuilder;
        const request = handlerInput.requestEnvelope.request;
        attributes.state = states.ANSWER;
        attributes.rice = "";
        attributes.amount = "";

        const intent = request.intent;
        let rice = intent.slots.Rice.value;
        if (!rice) {
            rice = '白米';
        }
        let amount = intent.slots.Amount.value; 
        if (!amount) {
            amount = 3;
        }
        
        return handlerInput.responseBuilder
            .speak(rice + 'の' + amount + '合の水の量は' + measureWater(rice, amount) + 'です')
            .reprompt(rice)
            .withSimpleCard('Hello World', '白米')
            .addDelegateDirective()
            .getResponse();
    }
};

const HelpIntentHandler = {
    canHandle(handlerInput) {
        return handlerInput.requestEnvelope.request.type === 'IntentRequest' &&
               handlerInput.requestEnvelope.request.intent.name === 'AMAZON.HelpIntent';
    },
    handle(handlerInput) {
        const speechText = 'これはヘルプです';

        return handlerInput.responseBuilder
            .speak(speechText)
            .reprompt(speechText)
            .withSimpleCard('Hello World', speechText)
            .getResponse();
    }
};

const ExitIntentHandler = {
    canHandle(handlerInput) {
        return handlerInput.requestEnvelope.request.type === 'IntentRequest'
            && (handlerInput.requestEnvelope.request.intent.name === 'AMAZON.CancelIntent'
                || handlerInput.requestEnvelope.request.intent.name === 'AMAZON.StopIntent');
    },
    handle(handlerInput) {
        const speechText = '了解しました。終了します。';

        return handlerInput.responseBuilder
            .speak(speechText)
            .getResponse();
    }
};

const ErrorHandler = {
    canHandle(handlerInput, error) {
        return error.name.startsWith('AskSdk');
    },
    handle(handlerInput, error) {
        return handlerInput.responseBuilder
            .speak('エラーになっているのでやめます')
            .getResponse();
    }
}

function measureWater(rice, amount) {
    let result;
    if (rice === '白米') {
        result = amount * 1.1;
    } else if (rice === '玄米') {
        result = amount * 1.2;
    } else if (rice === 'もち米') {
        result = amount * 1.3;
    }
    return result;
}
